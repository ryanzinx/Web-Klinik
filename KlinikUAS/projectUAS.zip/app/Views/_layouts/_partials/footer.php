<footer class=" main-footer">
    <strong>&copy; 2023 - Adrian Fadhali Wiratama - 312110329 - TI.21.A2 | Universitas Pelita Bangsa
</footer>